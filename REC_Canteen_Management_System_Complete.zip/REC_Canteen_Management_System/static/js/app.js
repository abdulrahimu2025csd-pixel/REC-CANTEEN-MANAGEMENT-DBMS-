
(() => {
  const cart = new Map();
  const cartItems = document.getElementById("cart-items");
  const cartCount = document.getElementById("cart-count");
  const cartTotal = document.getElementById("cart-total");
  const checkoutTotal = document.getElementById("checkout-total");
  const checkoutOpen = document.getElementById("checkout-open");
  const modal = document.getElementById("checkout-modal");
  const cartJson = document.getElementById("cart-json");
  const form = document.getElementById("checkout-form");

  const formatINR = n => new Intl.NumberFormat("en-IN", {
    style: "currency", currency: "INR", maximumFractionDigits: 2
  }).format(n);

  function renderCart() {
    if (!cartItems) return;
    const items = [...cart.values()];
    const count = items.reduce((sum, item) => sum + item.qty, 0);
    const total = items.reduce((sum, item) => sum + item.price * item.qty, 0);
    cartCount.textContent = count;
    cartTotal.textContent = formatINR(total);
    if (checkoutTotal) checkoutTotal.textContent = formatINR(total);
    checkoutOpen.disabled = items.length === 0;

    if (!items.length) {
      cartItems.innerHTML = '<div class="cart-empty"><span>🥡</span><b>Your next favourite goes here.</b><small>Add something delicious to begin.</small></div>';
      return;
    }
    cartItems.innerHTML = items.map(item => `
      <div class="cart-line">
        <div class="cart-line-main"><b>${escapeHtml(item.name)}</b><small>${escapeHtml(item.outlet)}</small><strong>${formatINR(item.price * item.qty)}</strong></div>
        <div class="quantity-control">
          <button type="button" data-qty-id="${item.id}" data-change="-1" aria-label="Decrease quantity">−</button>
          <span>${item.qty}</span>
          <button type="button" data-qty-id="${item.id}" data-change="1" aria-label="Increase quantity">+</button>
        </div>
      </div>`).join("");
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, char => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
    }[char]));
  }

  document.querySelectorAll("[data-add-id]").forEach(button => {
    button.addEventListener("click", () => {
      const id = Number(button.dataset.addId);
      const existing = cart.get(id);
      if (existing) {
        if (existing.qty >= 20) return;
        existing.qty += 1;
      } else {
        cart.set(id, {
          id, name: button.dataset.addName,
          price: Number(button.dataset.addPrice),
          outlet: button.dataset.addOutlet, qty: 1
        });
      }
      button.classList.add("added");
      button.textContent = "✓";
      setTimeout(() => { button.classList.remove("added"); button.textContent = "+"; }, 650);
      renderCart();
    });
  });

  if (cartItems) {
    cartItems.addEventListener("click", event => {
      const button = event.target.closest("[data-qty-id]");
      if (!button) return;
      const id = Number(button.dataset.qtyId);
      const item = cart.get(id);
      if (!item) return;
      item.qty += Number(button.dataset.change);
      if (item.qty <= 0) cart.delete(id);
      if (item.qty > 20) item.qty = 20;
      renderCart();
    });
  }

  function openModal() {
    if (!modal) return;
    cartJson.value = JSON.stringify([...cart.values()].map(({id, qty}) => ({id, qty})));
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
  }
  function closeModal() {
    if (!modal) return;
    modal.classList.remove("open");
    modal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
  }

  checkoutOpen?.addEventListener("click", openModal);
  document.getElementById("checkout-close")?.addEventListener("click", closeModal);
  modal?.addEventListener("click", event => { if (event.target === modal) closeModal(); });
  document.addEventListener("keydown", event => { if (event.key === "Escape") closeModal(); });
  form?.addEventListener("submit", event => {
    if (cart.size === 0) {
      event.preventDefault();
      closeModal();
      return;
    }
    cartJson.value = JSON.stringify([...cart.values()].map(({id, qty}) => ({id, qty})));
  });

  renderCart();

  // Small reveal effect without an animation library.
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("in-view");
        observer.unobserve(entry.target);
      }
    });
  }, {threshold: 0.08});
  document.querySelectorAll(".food-card, .stat-card, .data-panel").forEach(el => {
    el.classList.add("reveal");
    observer.observe(el);
  });
})();
