
import json
import os
import secrets
from datetime import datetime
from decimal import Decimal

import mysql.connector
from mysql.connector import Error
from dotenv import load_dotenv
from flask import Flask, abort, flash, redirect, render_template, request, session, url_for, send_from_directory
from werkzeug.security import check_password_hash, generate_password_hash
import qrcode
from io import BytesIO
import base64

load_dotenv()

FRONTEND_DIST = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "frontend", "dist"))

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "change-this-development-secret-before-sharing")
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.getenv("COOKIE_SECURE", "false").lower() == "true",
)

DB_CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "port": int(os.getenv("DB_PORT", "3306")),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", ""),
    "database": os.getenv("DB_NAME", "rec_canteen"),
    "charset": "utf8mb4",
    "use_unicode": True,
}


def get_connection():
    return mysql.connector.connect(**DB_CONFIG)


def initialize_database():
    """Create schema and seed menu/admin demo data. Existing data is preserved."""
    schema_path = os.path.join(os.path.dirname(__file__), "schema.sql")
    with open(schema_path, "r", encoding="utf-8") as f:
        script = f.read()

    # Execute statements one by one; schema.sql contains no stored procedures.
    # Connect without selecting a database first, so the first run can create it.
    bootstrap_config = {
        "host": DB_CONFIG["host"],
        "port": DB_CONFIG["port"],
        "user": DB_CONFIG["user"],
        "password": DB_CONFIG["password"],
        "charset": "utf8mb4",
        "use_unicode": True,
    }
    conn = mysql.connector.connect(**bootstrap_config)
    try:
        cursor = conn.cursor()
        for statement in script.split(";"):
            statement = statement.strip()
            if statement:
                cursor.execute(statement)
        conn.commit()
        cursor.close()
    finally:
        conn.close()

    conn = get_connection()
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT COUNT(*) AS n FROM admins")
        admin_count = cur.fetchone()["n"]
        if admin_count == 0:
            admins = [
                ("abdulrahim.u.2025.csd@rajalakshmi.edu.in", generate_password_hash("251701001")),
                ("bharath.s.2025.csd@rajalakshmi.edu.in", generate_password_hash("251701009")),
            ]
            cur.executemany(
                "INSERT INTO admins (email, password_hash) VALUES (%s, %s)",
                admins,
            )

        cur.execute("SELECT COUNT(*) AS n FROM outlets")
        if cur.fetchone()["n"] == 0:
            cur.executemany(
                "INSERT INTO outlets (name, description) VALUES (%s, %s)",
                [
                    ("Cafe (Cafe Seva)", "Meals, noodles, tiffin and snacks"),
                    ("Hotspot", "Maggi, hot drinks and bakery items"),
                    ("Yippee", "Noodles, snacks and quick bites"),
                    ("Wok On", "Fried rice, noodles and starters"),
                    ("REC Mart", "Stationery, daily-use items, drinks and snacks"),
                    ("Black Buck", "Coolers, sandwiches, fries, burgers and snacks"),
                    ("Domino's", "Vegetarian pizzas, sides, desserts and beverages"),
                    ("Fresh Juice", "Fresh fruit juices, sugarcane juice and coolers"),
                ],
            )

        cur.execute("SELECT COUNT(*) AS n FROM menu_items")
        if cur.fetchone()["n"] == 0:
            menu_path = os.path.join(os.path.dirname(__file__), "menu_seed.json")
            with open(menu_path, "r", encoding="utf-8") as mf:
                menu = json.load(mf)
            cur.execute("SELECT outlet_id, name FROM outlets")
            outlet_ids = {row["name"]: row["outlet_id"] for row in cur.fetchall()}
            rows = []
            for item in menu:
                rows.append((
                    outlet_ids[item["outlet"]],
                    item["name"],
                    item["category"],
                    Decimal(str(item["price"])),
                    item.get("image", ""),
                    item.get("available", True),
                ))
            cur.executemany(
                """INSERT INTO menu_items
                   (outlet_id, name, category, price, image_url, is_available)
                   VALUES (%s, %s, %s, %s, %s, %s)""",
                rows,
            )
        conn.commit()
        cur.close()
    finally:
        conn.close()


def query_all(sql, params=()):
    conn = get_connection()
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute(sql, params)
        rows = cur.fetchall()
        cur.close()
        return rows
    finally:
        conn.close()


def query_one(sql, params=()):
    rows = query_all(sql, params)
    return rows[0] if rows else None


def money(value):
    return f"₹{Decimal(str(value)):.2f}"


app.jinja_env.filters["money"] = money


@app.route("/interactive")
def interactive_index():
    dist_index = os.path.join(FRONTEND_DIST, "index.html")
    if os.path.exists(dist_index):
        return send_from_directory(FRONTEND_DIST, "index.html")
    return redirect(url_for("index"))


@app.route("/assets/<path:path>")
def serve_assets(path):
    assets_dir = os.path.join(FRONTEND_DIST, "assets")
    if os.path.exists(os.path.join(assets_dir, path)):
        return send_from_directory(assets_dir, path)
    abort(404)


@app.route("/")
def index():
    outlet_rows = query_all("SELECT outlet_id, name, description FROM outlets ORDER BY outlet_id")
    selected_outlet = request.args.get("outlet", type=int)
    category = request.args.get("category", "").strip()
    search = request.args.get("q", "").strip()

    sql = """
        SELECT m.menu_item_id, m.name, m.category, m.price, m.image_url,
               m.is_available, o.name AS outlet_name, o.outlet_id
        FROM menu_items m
        JOIN outlets o ON o.outlet_id = m.outlet_id
        WHERE m.is_available = TRUE
    """
    params = []
    if selected_outlet:
        sql += " AND o.outlet_id = %s"
        params.append(selected_outlet)
    if category:
        sql += " AND m.category = %s"
        params.append(category)
    if search:
        sql += " AND (m.name LIKE %s OR m.category LIKE %s OR o.name LIKE %s)"
        term = f"%{search}%"
        params.extend([term, term, term])
    sql += " ORDER BY o.name, m.category, m.name"
    items = query_all(sql, tuple(params))
    categories = query_all("""
        SELECT DISTINCT category FROM menu_items
        WHERE is_available = TRUE ORDER BY category
    """)
    return render_template(
        "index.html", outlets=outlet_rows, items=items, categories=categories,
        selected_outlet=selected_outlet, selected_category=category, search=search
    )


@app.post("/place-order")
def place_order():
    customer_name = request.form.get("customer_name", "").strip()
    phone = request.form.get("phone", "").strip()
    notes = request.form.get("notes", "").strip()
    raw_items = request.form.get("cart_json", "")
    if not customer_name or len(customer_name) > 100:
        flash("Please enter your name (up to 100 characters).", "error")
        return redirect(url_for("index"))
    digits = "".join(ch for ch in phone if ch.isdigit())
    if len(digits) < 10 or len(digits) > 15:
        flash("Enter a valid phone number containing 10 to 15 digits.", "error")
        return redirect(url_for("index"))
    if len(notes) > 250:
        flash("Order note must be 250 characters or fewer.", "error")
        return redirect(url_for("index"))

    try:
        cart = json.loads(raw_items)
    except (ValueError, TypeError):
        cart = None
    if not isinstance(cart, list) or not cart or len(cart) > 60:
        flash("Your cart is empty or invalid. Please add items and try again.", "error")
        return redirect(url_for("index"))

    normalized = {}
    for entry in cart:
        try:
            item_id = int(entry.get("id"))
            qty = int(entry.get("qty"))
        except (ValueError, TypeError, AttributeError):
            flash("Your cart contains invalid items.", "error")
            return redirect(url_for("index"))
        if item_id <= 0 or qty < 1 or qty > 20:
            flash("Each item quantity must be between 1 and 20.", "error")
            return redirect(url_for("index"))
        normalized[item_id] = normalized.get(item_id, 0) + qty
    if any(qty > 20 for qty in normalized.values()):
        flash("Maximum quantity per item is 20.", "error")
        return redirect(url_for("index"))

    conn = get_connection()
    try:
        conn.start_transaction()
        cur = conn.cursor(dictionary=True)
        placeholders = ",".join(["%s"] * len(normalized))
        cur.execute(
            f"""SELECT menu_item_id, name, price, outlet_id, is_available
                FROM menu_items WHERE menu_item_id IN ({placeholders}) FOR UPDATE""",
            tuple(normalized.keys()),
        )
        db_items = cur.fetchall()
        if len(db_items) != len(normalized) or any(not row["is_available"] for row in db_items):
            conn.rollback()
            flash("One or more items are no longer available. Please refresh the menu.", "error")
            return redirect(url_for("index"))

        by_id = {row["menu_item_id"]: row for row in db_items}
        total = sum((Decimal(str(by_id[i]["price"])) * qty for i, qty in normalized.items()), Decimal("0.00"))
        token = secrets.token_urlsafe(24)
        cur.execute(
            """INSERT INTO orders
               (customer_name, phone, notes, total_amount, order_status, payment_status, qr_token)
               VALUES (%s, %s, %s, %s, 'Placed', 'Pay at counter', %s)""",
            (customer_name, digits, notes or None, total, token),
        )
        order_id = cur.lastrowid
        order_rows = []
        for item_id, qty in normalized.items():
            item = by_id[item_id]
            line_total = Decimal(str(item["price"])) * qty
            order_rows.append((order_id, item_id, qty, item["price"], line_total))
        cur.executemany(
            """INSERT INTO order_items
               (order_id, menu_item_id, quantity, unit_price, line_total)
               VALUES (%s, %s, %s, %s, %s)""",
            order_rows,
        )
        conn.commit()
        cur.close()
    except Error:
        conn.rollback()
        app.logger.exception("Database error while placing order")
        flash("We couldn't place your order. Please try again.", "error")
        return redirect(url_for("index"))
    finally:
        conn.close()
    return redirect(url_for("order_receipt", order_id=order_id, token=token))


@app.route("/order/<int:order_id>")
def order_receipt(order_id):
    token = request.args.get("token", "")
    if not token:
        abort(404)
    order = query_one(
        """SELECT order_id, customer_name, total_amount, order_status, payment_status,
                  created_at, qr_token
           FROM orders WHERE order_id = %s AND qr_token = %s""",
        (order_id, token),
    )
    if not order:
        abort(404)
    order_items = query_all(
        """SELECT oi.quantity, oi.unit_price, oi.line_total, m.name, o.name AS outlet_name
           FROM order_items oi
           JOIN menu_items m ON m.menu_item_id = oi.menu_item_id
           JOIN outlets o ON o.outlet_id = m.outlet_id
           WHERE oi.order_id = %s ORDER BY oi.order_item_id""",
        (order_id,),
    )
    # QR payload is a non-guessable receipt URL. No personal details are encoded in the QR itself.
    receipt_url = url_for("verify_order", token=order["qr_token"], _external=True)
    qr_img = qrcode.make(receipt_url)
    buffer = BytesIO()
    qr_img.save(buffer, format="PNG")
    qr_base64 = base64.b64encode(buffer.getvalue()).decode("ascii")
    return render_template("receipt.html", order=order, items=order_items, qr_base64=qr_base64)


@app.route("/verify/<token>")
def verify_order(token):
    # This is a limited receipt verification page. It does not allow status changes.
    order = query_one(
        """SELECT order_id, customer_name, total_amount, order_status, created_at
           FROM orders WHERE qr_token = %s""",
        (token,),
    )
    if not order:
        abort(404)
    items = query_all(
        """SELECT m.name, oi.quantity, oi.unit_price, oi.line_total, o.name AS outlet_name
           FROM order_items oi JOIN menu_items m ON m.menu_item_id = oi.menu_item_id
           JOIN outlets o ON o.outlet_id = m.outlet_id
           WHERE oi.order_id = %s""",
        (order["order_id"],),
    )
    return render_template("verify.html", order=order, items=items)


@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if session.get("admin_id"):
        return redirect(url_for("admin_dashboard"))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        admin = query_one(
            "SELECT admin_id, email, password_hash FROM admins WHERE email = %s",
            (email,),
        )
        if admin and check_password_hash(admin["password_hash"], password):
            session.clear()
            session["admin_id"] = admin["admin_id"]
            session["admin_email"] = admin["email"]
            return redirect(url_for("admin_dashboard"))
        flash("Invalid email or password.", "error")
    return render_template("admin_login.html")


@app.route("/admin")
def admin_dashboard():
    if not session.get("admin_id"):
        return redirect(url_for("admin_login"))
    q = request.args.get("q", "").strip()
    status = request.args.get("status", "").strip()
    date_from = request.args.get("from", "").strip()
    date_to = request.args.get("to", "").strip()
    sql = """SELECT order_id, customer_name, phone, total_amount, order_status,
                    payment_status, created_at
             FROM orders WHERE 1=1"""
    params = []
    if q:
        sql += " AND (CAST(order_id AS CHAR) LIKE %s OR customer_name LIKE %s OR phone LIKE %s)"
        term = f"%{q}%"
        params.extend([term, term, term])
    if status in {"Placed", "Preparing", "Ready", "Collected", "Cancelled"}:
        sql += " AND order_status = %s"
        params.append(status)
    if date_from:
        sql += " AND created_at >= %s"
        params.append(date_from + " 00:00:00")
    if date_to:
        sql += " AND created_at <= %s"
        params.append(date_to + " 23:59:59")
    sql += " ORDER BY created_at DESC LIMIT 500"
    orders = query_all(sql, tuple(params))
    totals = query_one("""
        SELECT COUNT(*) AS order_count, COALESCE(SUM(total_amount), 0) AS sales_total
        FROM orders
    """)
    popular = query_all("""
        SELECT m.name, SUM(oi.quantity) AS units_sold, SUM(oi.line_total) AS revenue
        FROM order_items oi JOIN menu_items m ON m.menu_item_id = oi.menu_item_id
        GROUP BY m.menu_item_id, m.name
        ORDER BY units_sold DESC LIMIT 5
    """)
    return render_template(
        "admin_dashboard.html", orders=orders, totals=totals, popular=popular,
        q=q, status=status, date_from=date_from, date_to=date_to
    )


@app.route("/admin/order/<int:order_id>")
def admin_order_detail(order_id):
    if not session.get("admin_id"):
        return redirect(url_for("admin_login"))
    order = query_one("SELECT * FROM orders WHERE order_id = %s", (order_id,))
    if not order:
        abort(404)
    items = query_all("""
        SELECT oi.quantity, oi.unit_price, oi.line_total, m.name, m.category, o.name AS outlet_name
        FROM order_items oi JOIN menu_items m ON m.menu_item_id = oi.menu_item_id
        JOIN outlets o ON o.outlet_id = m.outlet_id
        WHERE oi.order_id = %s ORDER BY oi.order_item_id
    """, (order_id,))
    return render_template("admin_order_detail.html", order=order, items=items)


@app.route("/admin/logout", methods=["POST"])
def admin_logout():
    session.clear()
    return redirect(url_for("admin_login"))


@app.errorhandler(404)
def not_found(_error):
    return render_template("404.html"), 404


if __name__ == "__main__":
    try:
        initialize_database()
    except Error as exc:
        print("\n[DATABASE ERROR] Could not initialize the database.")
        print("Check that MySQL is running and your .env credentials are correct.")
        print(f"Details: {exc}\n")
        raise
    print("\nREC Canteen is starting at http://127.0.0.1:5000")
    print("Demo admin accounts are listed in README.md. Change them before any real deployment.\n")
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "5000")), debug=os.getenv("FLASK_DEBUG", "false").lower() == "true")
