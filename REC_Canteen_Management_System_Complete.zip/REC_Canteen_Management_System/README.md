
# REC Canteen Management System

A student-facing canteen ordering demo and read-only admin dashboard built with Flask, MySQL, HTML, CSS and JavaScript.

## Features
- Eight outlets from the provided menu documents.
- Illustrative sample prices in INR. These are not verified shop prices.
- Student ordering without account registration.
- Server-side price lookup and total calculation. Browser-submitted prices are never trusted.
- Orders and order lines saved to MySQL in a transaction.
- Unique QR receipt for each order.
- Two demo admin accounts with password hashes.
- Admin dashboard is read-only: admins can view orders and order details but cannot modify/delete records.
- Search and date/status filters for viewing records.
- Mobile-responsive UI and mascot/logo assets.

## Requirements
- Windows 10/11
- Python 3.10 or newer
- MySQL Server installed and running
- VS Code (recommended)

## Setup on Windows

### 1. Extract and open
Extract `REC_Canteen_Management_System.zip` to a folder, for example:
`C:\Users\YourName\Documents\REC-Canteen`

In VS Code choose **File → Open Folder** and select that folder.

### 2. Create a Python virtual environment
Open **Terminal → New Terminal** in VS Code and run:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, use Command Prompt terminal instead:
```bat
.venv\Scripts\activate.bat
```

### 3. Install dependencies
```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Configure MySQL
Copy `.env.example` to a new file named `.env` in the project root. Open `.env` and replace `YOUR_MYSQL_PASSWORD` with your MySQL password.

If your MySQL `root` account has no password, leave `DB_PASSWORD=` blank.

The app creates the `rec_canteen` database and tables automatically on first launch, provided the MySQL account has permission to create a database. Alternatively, run `schema.sql` in MySQL Workbench first if your account has restricted permissions. Do not put `.env` into a public repository or share it.

### 5. Start the app
Make sure MySQL Server is running, then in the activated VS Code terminal:

```powershell
python app.py
```

Open this address in your browser:
**http://127.0.0.1:5000**

Keep the terminal open while using the application. Press `Ctrl+C` in the terminal to stop it.

## Demo admin login
Open **http://127.0.0.1:5000/admin/login**

- Admin 1 email: `abdulrahim.u.2025.csd@rajalakshmi.edu.in`
- Admin 1 password: `251701001`
- Admin 2 email: `bharath.s.2025.csd@rajalakshmi.edu.in`
- Admin 2 password: `251701009`

These are demonstration credentials only. Do not reuse them for a real deployment. This project seeds the two admin accounts only if the `admins` table is empty. If you change credentials, update them securely in the database; passwords must remain hashed.

## How to demonstrate the database
1. Open the student menu and select items from any outlet.
2. Add them to the cart and enter a name and valid phone number.
3. Place the order. A receipt and QR code appear.
4. Open the admin login in another tab and sign in.
5. View the order in the read-only table, then open its details.
6. In MySQL Workbench run:
   ```sql
   USE rec_canteen;
   SELECT * FROM orders ORDER BY created_at DESC;
   SELECT * FROM order_items ORDER BY order_item_id DESC;
   SELECT o.order_id, o.customer_name, m.name AS item, oi.quantity,
          oi.unit_price, oi.line_total
   FROM orders o
   JOIN order_items oi ON oi.order_id = o.order_id
   JOIN menu_items m ON m.menu_item_id = oi.menu_item_id
   ORDER BY o.order_id DESC;
   ```

## Notes and limitations
- All listed prices are sample/estimated demonstration prices. Confirm with the actual shops before any real use.
- Payment is **pay at counter**. No real payment gateway is connected.
- Students do not create accounts. The order receipt URL contains a random token; keep it private.
- Admin access is read-only in the application UI/routes. For a real deployment, also use a dedicated MySQL application account with least-privilege grants, HTTPS, CSRF protection and stronger production configuration.
- The demo server binds to `127.0.0.1`, which is local to your laptop. It is not publicly accessible and is not automatically accessible from phones on another device.
- Menu images are represented with food illustrations/gradients in the interface. The supplied REC logo and mascot images are included in `static/img`.
