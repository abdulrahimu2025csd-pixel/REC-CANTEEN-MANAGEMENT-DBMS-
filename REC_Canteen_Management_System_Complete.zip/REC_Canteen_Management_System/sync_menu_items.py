import json
import os
import mysql.connector
from decimal import Decimal
from dotenv import load_dotenv

load_dotenv()

outlets_data = [
    {
        'name': 'Black Buck',
        'desc': 'Snacks, Sandwiches, Burgers, Fries & Coolers',
        'items': [
            # 1. Mojitos & Coolers
            ('Classic Mint Mojito', 'Mojitos & Coolers', 80),
            ('Blue Lagoon Mojito', 'Mojitos & Coolers', 85),
            ('Green Apple Mojito', 'Mojitos & Coolers', 85),
            ('Watermelon Mojito', 'Mojitos & Coolers', 85),
            ('Strawberry Mojito', 'Mojitos & Coolers', 85),
            ('Blueberry Mojito', 'Mojitos & Coolers', 90),
            ('Passion Fruit Mojito', 'Mojitos & Coolers', 90),
            ('Lemon Mint Mojito', 'Mojitos & Coolers', 80),
            ('Mango Mojito', 'Mojitos & Coolers', 85),
            ('Kiwi Mojito', 'Mojitos & Coolers', 90),
            ('Virgin Mojito', 'Mojitos & Coolers', 80),
            ('Classic Lemon Soda', 'Mojitos & Coolers', 40),
            # 2. Cold Drinks & Beverages
            ('Fresh Lime Juice', 'Cold Drinks & Beverages', 35),
            ('Iced Lemon Tea', 'Cold Drinks & Beverages', 50),
            ('Peach Iced Tea', 'Cold Drinks & Beverages', 55),
            ('Cold Coffee', 'Cold Drinks & Beverages', 60),
            ('Chocolate Cold Coffee', 'Cold Drinks & Beverages', 75),
            ('Lemon Soda', 'Cold Drinks & Beverages', 40),
            ('Blue Lagoon Cooler', 'Cold Drinks & Beverages', 70),
            ('Fruit Punch', 'Cold Drinks & Beverages', 75),
            ('Packaged Soft Drinks', 'Cold Drinks & Beverages', 40),
            ('Packaged Drinking Water', 'Cold Drinks & Beverages', 20),
            # 3. Sandwiches
            ('Veg Sandwich', 'Sandwiches', 50),
            ('Grilled Veg Sandwich', 'Sandwiches', 70),
            ('Cheese Sandwich', 'Sandwiches', 75),
            ('Cheese Corn Sandwich', 'Sandwiches', 85),
            ('Paneer Sandwich', 'Sandwiches', 85),
            ('Paneer Tikka Sandwich', 'Sandwiches', 100),
            ('Club Veg Sandwich', 'Sandwiches', 110),
            ('Corn & Cheese Sandwich', 'Sandwiches', 85),
            ('Spicy Masala Sandwich', 'Sandwiches', 75),
            ('Chocolate Sandwich', 'Sandwiches', 80),
            # 4. French Fries & Potato Sides
            ('Classic Salted French Fries', 'French Fries & Potato Sides', 70),
            ('Peri Peri Fries', 'French Fries & Potato Sides', 85),
            ('Masala Fries', 'French Fries & Potato Sides', 80),
            ('Cheesy Fries', 'French Fries & Potato Sides', 100),
            ('Loaded Cheese Fries', 'French Fries & Potato Sides', 120),
            ('Garlic Fries', 'French Fries & Potato Sides', 85),
            ('Potato Wedges', 'French Fries & Potato Sides', 90),
            ('Crispy Potato Pops', 'French Fries & Potato Sides', 80),
            # 5. Burgers & Wraps
            ('Veg Burger', 'Burgers & Wraps', 80),
            ('Cheese Veg Burger', 'Burgers & Wraps', 100),
            ('Paneer Burger', 'Burgers & Wraps', 110),
            ('Veg Wrap', 'Burgers & Wraps', 90),
            ('Paneer Wrap', 'Burgers & Wraps', 110),
            ('Spicy Veg Roll', 'Burgers & Wraps', 80),
            # 6. Quick Bites & Snacks
            ('Veg Nuggets', 'Quick Bites & Snacks', 80),
            ('Cheese Balls', 'Quick Bites & Snacks', 90),
            ('Onion Rings', 'Quick Bites & Snacks', 75),
            ('Garlic Bread', 'Quick Bites & Snacks', 60),
            ('Cheese Garlic Bread', 'Quick Bites & Snacks', 85),
            ('Nachos with Cheese Dip', 'Quick Bites & Snacks', 90),
            ('Masala Maggi', 'Quick Bites & Snacks', 50),
            ('Veg Puff', 'Quick Bites & Snacks', 25),
            ('Samosa', 'Quick Bites & Snacks', 20),
            ('Popcorn', 'Quick Bites & Snacks', 40),
            # 7. Dips & Extras
            ('Mayonnaise', 'Dips & Extras', 15),
            ('Cheese Dip', 'Dips & Extras', 25),
            ('Peri Peri Seasoning', 'Dips & Extras', 10),
            ('Tomato Ketchup', 'Dips & Extras', 5),
            ('Chilli Sauce', 'Dips & Extras', 10),
            ('Mint Dip', 'Dips & Extras', 15),
        ]
    },
    {
        'name': 'Yippee',
        'desc': 'Yippee Noodles Varieties, Snacks & Quick Bites',
        'items': [
            # Yippee Noodles - Varieties
            ('Classic Yippee Noodles', 'Yippee Noodles', 40),
            ('Schezwan Yippee Noodles', 'Yippee Noodles', 50),
            ('Masala Yippee Noodles', 'Yippee Noodles', 45),
            ('Cheese Yippee Noodles', 'Yippee Noodles', 65),
            ('Peri-Peri Yippee Noodles', 'Yippee Noodles', 50),
            ('Chilli Garlic Yippee Noodles', 'Yippee Noodles', 50),
            ('Butter Yippee Noodles', 'Yippee Noodles', 55),
            ('Double Masala Yippee Noodles', 'Yippee Noodles', 50),
            # Snacks
            ('Chips & Packaged Snacks', 'Snacks', 20),
            ('Biscuits', 'Snacks', 20),
            ('Chocolate Bars', 'Snacks', 30),
            ('Cream Bun', 'Snacks', 20),
            ('Jam Bun', 'Snacks', 20),
            ('Veg Puff', 'Snacks', 20),
            ('Egg Puff', 'Snacks', 25),
            # Quick Bites
            ('Bread Omelette', 'Quick Bites', 45),
            ('Egg Sandwich', 'Quick Bites', 50),
            ('Veg Sandwich', 'Quick Bites', 40),
            ('French Fries', 'Quick Bites', 60),
        ]
    },
    {
        'name': 'Wok On',
        'desc': 'Fried Rice, Wok Noodles & Sizzling Starters',
        'items': [
            # Fried Rice
            ('Egg Fried Rice', 'Fried Rice', 90),
            ('Gobi Fried Rice', 'Fried Rice', 90),
            ('Mushroom Rice', 'Fried Rice', 100),
            ('Paneer Rice', 'Fried Rice', 110),
            # Noodles
            ('Egg Noodles', 'Noodles', 90),
            ('Paneer Noodles', 'Noodles', 110),
            ('Gobi Noodles', 'Noodles', 90),
            ('Mushroom Noodles', 'Noodles', 100),
            # Starters
            ('Gobi Manchurian', 'Starters', 90),
            ('Paneer Manchurian', 'Starters', 110),
            ('Mushroom Manchurian', 'Starters', 100),
        ]
    },
    {
        'name': 'REC Mart',
        'desc': 'Stationery, Grocery, Juices, Snacks & Daily Supplies',
        'items': [
            # 1. Stationery Items
            ('Pencils', 'Stationery', 10),
            ('Pens (Ballpoint, Gel, Blue, Black, Red)', 'Stationery', 15),
            ('Pencil Box / Geometry Box', 'Stationery', 65),
            ('Scale / Ruler', 'Stationery', 15),
            ('Eraser', 'Stationery', 5),
            ('Sharpener', 'Stationery', 5),
            ('Highlighters', 'Stationery', 30),
            ('Markers', 'Stationery', 25),
            ('Sketch Pens', 'Stationery', 40),
            ('Crayons / Colour Pencils', 'Stationery', 50),
            ('Notebooks', 'Stationery', 45),
            ('Long Notebook / Record Notebook', 'Stationery', 75),
            ('Loose Sheets', 'Stationery', 30),
            ('A4 Paper', 'Stationery', 100),
            ('Sticky Notes', 'Stationery', 35),
            ('Index Tabs', 'Stationery', 25),
            ('Paper Clips', 'Stationery', 20),
            ('Stapler & Staples', 'Stationery', 55),
            ('Glue Stick', 'Stationery', 25),
            ('Fevicol', 'Stationery', 20),
            ('Scissors', 'Stationery', 40),
            ('Cello Tape', 'Stationery', 20),
            ('Correction Pen / Whitener', 'Stationery', 30),
            ('Compass', 'Stationery', 35),
            ('Protractor', 'Stationery', 15),
            ('Set Square', 'Stationery', 25),
            ('Calculator', 'Stationery', 150),
            ('File / Folder', 'Stationery', 35),
            ('Brown Cover', 'Stationery', 10),
            ('Chart Paper', 'Stationery', 15),
            ('Drawing Book', 'Stationery', 50),
            ('Exam Pad', 'Stationery', 60),
            # 2. Grocery & Daily-Use Items
            ('Rice', 'Grocery & Daily-Use', 70),
            ('Wheat Flour / Atta', 'Grocery & Daily-Use', 60),
            ('Sugar', 'Grocery & Daily-Use', 50),
            ('Salt', 'Grocery & Daily-Use', 25),
            ('Cooking Oil', 'Grocery & Daily-Use', 140),
            ('Rava / Sooji', 'Grocery & Daily-Use', 40),
            ('Vermicelli / Semiya', 'Grocery & Daily-Use', 35),
            ('Dhal / Lentils', 'Grocery & Daily-Use', 90),
            ('Spices & Masala Powders', 'Grocery & Daily-Use', 40),
            ('Tea Powder', 'Grocery & Daily-Use', 80),
            ('Coffee Powder', 'Grocery & Daily-Use', 95),
            ('Milk Powder', 'Grocery & Daily-Use', 65),
            ('Instant Noodles', 'Grocery & Daily-Use', 30),
            ('Biscuits', 'Grocery & Daily-Use', 30),
            ('Bread', 'Grocery & Daily-Use', 35),
            ('Jam', 'Grocery & Daily-Use', 45),
            ('Pickle', 'Grocery & Daily-Use', 40),
            ('Sauces / Ketchup', 'Grocery & Daily-Use', 35),
            ('Bath Soap', 'Grocery & Daily-Use', 35),
            ('Handwash', 'Grocery & Daily-Use', 65),
            ('Shampoo', 'Grocery & Daily-Use', 80),
            ('Hair Oil', 'Grocery & Daily-Use', 60),
            ('Toothpaste', 'Grocery & Daily-Use', 55),
            ('Toothbrush', 'Grocery & Daily-Use', 30),
            ('Detergent Powder', 'Grocery & Daily-Use', 75),
            ('Washing Soap Bar', 'Grocery & Daily-Use', 25),
            ('Dishwash Liquid / Bar', 'Grocery & Daily-Use', 30),
            ('Floor Cleaner', 'Grocery & Daily-Use', 70),
            ('Toilet Cleaner', 'Grocery & Daily-Use', 80),
            ('Scrub Pad', 'Grocery & Daily-Use', 15),
            ('Tissue / Napkins', 'Grocery & Daily-Use', 40),
            ('Sanitary Napkins', 'Grocery & Daily-Use', 75),
            ('Garbage Bags', 'Grocery & Daily-Use', 50),
            # 3. Juices & Drinks
            ('Cavins', 'Juices & Drinks', 40),
            ('Minute Maid Juice', 'Juices & Drinks', 35),
            ('Keventers', 'Juices & Drinks', 65),
            ('Frooti', 'Juices & Drinks', 20),
            ('Smoothie Drinks', 'Juices & Drinks', 55),
            ('Slice', 'Juices & Drinks', 20),
            ('Real Fruit Juice', 'Juices & Drinks', 30),
            ('Maaza', 'Juices & Drinks', 20),
            ('Tropicana Juice', 'Juices & Drinks', 30),
            ('Coconut Water', 'Juices & Drinks', 45),
            ('Paper Boat Drinks', 'Juices & Drinks', 35),
            # 4. Chips & Packaged Snacks
            ('Lays', 'Packaged Snacks', 20),
            ('Haldirams Namkeen', 'Packaged Snacks', 35),
            ('Kurkure', 'Packaged Snacks', 20),
            ('Mixture', 'Packaged Snacks', 30),
            ('Doritos', 'Packaged Snacks', 30),
            ('Murukku', 'Packaged Snacks', 25),
            ('Bingo! Mad Angles', 'Packaged Snacks', 20),
            ('Popcorn', 'Packaged Snacks', 30),
            ('Uncle Chipps', 'Packaged Snacks', 20),
            ('Nachos', 'Packaged Snacks', 40),
            ('Pringles', 'Packaged Snacks', 110),
            ('Salted Peanuts', 'Packaged Snacks', 25),
            # 5. Chocolates & Candies
            ('KitKat', 'Chocolates & Candies', 30),
            ('Fuse', 'Chocolates & Candies', 35),
            ('Cadbury Dairy Milk', 'Chocolates & Candies', 40),
            ('Kinder Joy', 'Chocolates & Candies', 50),
            ('Milkybar', 'Chocolates & Candies', 20),
            ('M&Ms', 'Chocolates & Candies', 50),
            ('5 Star', 'Chocolates & Candies', 20),
            ('Eclairs', 'Chocolates & Candies', 5),
            ('Perk', 'Chocolates & Candies', 15),
            ('Melody', 'Chocolates & Candies', 5),
            ('Munch', 'Chocolates & Candies', 15),
            ('Pulse Candy', 'Chocolates & Candies', 2),
            ('Snickers', 'Chocolates & Candies', 40),
            ('Lollipop', 'Chocolates & Candies', 10),
            ('Mars', 'Chocolates & Candies', 50),
        ]
    },
    {
        'name': 'Cafe (Cafe Seva)',
        'desc': 'Bakery, Main Course Rice, Noodles, Parotta & Morning Tiffin',
        'items': [
            # Bakery Items
            ('Egg Puff', 'Bakery Items', 25),
            ('Veg Puff', 'Bakery Items', 20),
            ('Jam Bun', 'Bakery Items', 20),
            ('Cream Bun', 'Bakery Items', 20),
            # Snacks - Chips & Packaged Snacks
            ('Kurkure', 'Snacks', 20),
            ('Lays', 'Snacks', 20),
            ('Doritos', 'Snacks', 30),
            ('Mad Angles', 'Snacks', 20),
            # Branded Biscuits & Cookies
            ('Oreo', 'Biscuits & Cookies', 30),
            ('Happy Happy', 'Biscuits & Cookies', 15),
            ('Dark Fantasy', 'Biscuits & Cookies', 40),
            ('Hide & Seek', 'Biscuits & Cookies', 35),
            ('Good Day', 'Biscuits & Cookies', 25),
            ('Bourbon', 'Biscuits & Cookies', 30),
            # Main Course
            ('Sambar Rice', 'Main Course', 45),
            ('Curd Rice', 'Main Course', 40),
            ('Egg Rice', 'Main Course', 65),
            ('Veg Biryani', 'Main Course', 70),
            # Noodles
            ('Egg Noodles', 'Noodles', 70),
            ('Veg Noodles', 'Noodles', 60),
            # Parotta Items
            ('Kothu Parotta', 'Parotta Items', 75),
            # Morning Tiffin
            ('Idli', 'Morning Tiffin', 30),
            ('Dosa', 'Morning Tiffin', 45),
            ('Pongal', 'Morning Tiffin', 40),
            ('Poori', 'Morning Tiffin', 45),
            ('Chapati', 'Morning Tiffin', 40),
            # Egg Items
            ('Omelette', 'Egg Items', 30),
        ]
    },
    {
        'name': "Domino's",
        'desc': 'Vegetarian Pizzas, Garlic Breads, Pastas, Desserts & Combos',
        'items': [
            # 1. Veg Pizzas
            ('Margherita', 'Veg Pizzas', 149),
            ('Double Cheese Margherita', 'Veg Pizzas', 199),
            ('Farmhouse', 'Veg Pizzas', 249),
            ('Peppy Paneer', 'Veg Pizzas', 249),
            ('Veg Extravaganza', 'Veg Pizzas', 299),
            ('Veggie Paradise', 'Veg Pizzas', 239),
            ('Fresh Veggie', 'Veg Pizzas', 209),
            ('Corn n Cheese', 'Veg Pizzas', 189),
            ('Deluxe Veggie', 'Veg Pizzas', 269),
            ('Mexican Green Wave', 'Veg Pizzas', 259),
            ('Indi Tandoori Paneer', 'Veg Pizzas', 279),
            ('Paneer Makhani', 'Veg Pizzas', 269),
            ('Veg Loaded', 'Veg Pizzas', 199),
            ('Golden Corn', 'Veg Pizzas', 179),
            ('Capsicum & Red Paprika with Videshi Hot Sauce', 'Veg Pizzas', 219),
            # 2. Pizza Mania & Value Pizzas - Veg
            ('Margherita (Pizza Mania)', 'Pizza Mania', 79),
            ('Golden Corn (Pizza Mania)', 'Pizza Mania', 89),
            ('Fresh Veggie (Pizza Mania)', 'Pizza Mania', 99),
            ('Veg Loaded (Pizza Mania)', 'Pizza Mania', 119),
            ('Paneer & Capsicum with Videshi Hot Sauce', 'Pizza Mania', 129),
            ('Capsicum & Red Paprika (Pizza Mania)', 'Pizza Mania', 99),
            # 4. Garlic Breads & Veg Sides
            ('Garlic Breadsticks', 'Garlic Breads & Sides', 99),
            ('Classic Stuffed Garlic Bread', 'Garlic Breads & Sides', 149),
            ('Paneer Tikka Stuffed Garlic Bread', 'Garlic Breads & Sides', 169),
            ('Korean Corn & Jalapeno Garlic Bread', 'Garlic Breads & Sides', 159),
            ('Fiery Corn & Jalapeno Garlic Bread', 'Garlic Breads & Sides', 159),
            ('Makhani Corn & Jalapeno Garlic Bread', 'Garlic Breads & Sides', 159),
            ('Korean Paneer Tikka Garlic Bread', 'Garlic Breads & Sides', 179),
            ('Fiery Paneer Tikka Garlic Bread', 'Garlic Breads & Sides', 179),
            ('Makhani Paneer Tikka Garlic Bread', 'Garlic Breads & Sides', 179),
            ('Cheesy Dip', 'Garlic Breads & Sides', 35),
            ('Peri Peri Dip', 'Garlic Breads & Sides', 35),
            ('Tomato Ketchup', 'Garlic Breads & Sides', 5),
            ('Cheesy Potato Bites', 'Garlic Breads & Sides', 89),
            # 5. Tacos & Parcels - Veg
            ('Taco Mexicana Veg', 'Tacos & Parcels', 139),
            ('Veg Parcel', 'Tacos & Parcels', 59),
            # 6. Pasta - Veg
            ('Veg Pasta', 'Pasta', 119),
            ('Creamy / White Sauce Pasta', 'Pasta', 139),
            # 7. Desserts - Veg Varieties
            ('Chocolate Mousse', 'Desserts', 99),
            ('Butterscotch Mousse', 'Desserts', 99),
            ('Blueberry Mousse', 'Desserts', 109),
            ('Strawberry Mousse', 'Desserts', 109),
            ('Vanilla Mousse', 'Desserts', 89),
            ('Chocolate Brownie', 'Desserts', 99),
            ('Choco Lava Cake', 'Desserts', 109),
            ('Red Velvet Lava Cake', 'Desserts', 129),
            ('Chocolate Pastry / Cake', 'Desserts', 89),
            ('Blueberry Cheesecake', 'Desserts', 149),
            ('Strawberry Cheesecake', 'Desserts', 149),
            ('Butterscotch Cake / Pastry', 'Desserts', 89),
            ('Vanilla Cake / Pastry', 'Desserts', 79),
            ('Ice Cream Cups', 'Desserts', 45),
            # 8. Beverages
            ('Coca-Cola', 'Beverages', 45),
            ('Coca-Cola Zero Sugar', 'Beverages', 45),
            ('Sprite', 'Beverages', 45),
            ('Packaged Drinking Water', 'Beverages', 20),
            # 9. Vegetarian Combos & Meals
            ('Meal for 2: Farmhouse & Peppy Paneer', 'Combos & Meals', 499),
            ('Meal for 2: Farmhouse & Veg Extravaganza', 'Combos & Meals', 549),
            ('Meal for 2: Veg Paradise & Farmhouse', 'Combos & Meals', 489),
            ('Meal for 4: Peppy Paneer & Farmhouse', 'Combos & Meals', 899),
            ('Meal for 4: Margherita & Peppy Paneer', 'Combos & Meals', 799),
            ('Margherita + Garlic Bread + Coke', 'Combos & Meals', 289),
            ('Farmhouse + Garlic Bread + Beverage', 'Combos & Meals', 379),
            ('Garlic Breadsticks + Cheesy Dip', 'Combos & Meals', 129),
            ('Garlic Breadsticks + Beverage', 'Combos & Meals', 139),
            ('Ultimate Cheese Burst Deluxe Combo (Veg)', 'Combos & Meals', 599),
        ]
    },
    {
        'name': 'Fresh Juice',
        'desc': 'Fresh Fruit Juices, Sugarcane Juice, Coolers & Specials',
        'items': [
            # 1. Fresh Fruit Juices
            ('Orange Juice', 'Fresh Fruit Juices', 50),
            ('Sweet Lime (Mosambi) Juice', 'Fresh Fruit Juices', 50),
            ('Lemon Juice', 'Fresh Fruit Juices', 30),
            ('Watermelon Juice', 'Fresh Fruit Juices', 40),
            ('Muskmelon Juice', 'Fresh Fruit Juices', 45),
            ('Pineapple Juice', 'Fresh Fruit Juices', 50),
            ('Grape Juice', 'Fresh Fruit Juices', 50),
            ('Pomegranate Juice', 'Fresh Fruit Juices', 70),
            ('Apple Juice', 'Fresh Fruit Juices', 60),
            ('Mango Juice (seasonal)', 'Fresh Fruit Juices', 60),
            ('Guava Juice', 'Fresh Fruit Juices', 50),
            ('Papaya Juice', 'Fresh Fruit Juices', 45),
            ('Carrot Juice', 'Fresh Fruit Juices', 50),
            ('Beetroot Juice', 'Fresh Fruit Juices', 50),
            ('ABC Juice (Apple-Beetroot-Carrot)', 'Fresh Fruit Juices', 75),
            ('Mixed Fruit Juice', 'Fresh Fruit Juices', 60),
            ('Kiwi Juice', 'Fresh Fruit Juices', 75),
            ('Dragon Fruit Juice', 'Fresh Fruit Juices', 80),
            # 2. Sugarcane Juice
            ('Fresh Sugarcane Juice', 'Sugarcane Juice', 30),
            ('Sugarcane + Lemon', 'Sugarcane Juice', 35),
            ('Sugarcane + Ginger', 'Sugarcane Juice', 35),
            ('Sugarcane + Mint', 'Sugarcane Juice', 35),
            # 3. Lemon & Coolers
            ('Fresh Lime Juice', 'Lemon & Coolers', 25),
            ('Mint Lemon Juice', 'Lemon & Coolers', 35),
            ('Salted Lemon Juice', 'Lemon & Coolers', 25),
            ('Sweet Lemon Juice', 'Lemon & Coolers', 30),
            ('Fresh Lime Soda', 'Lemon & Coolers', 35),
            # 4. Seasonal & Special Fresh Juices
            ('Seasonal Fruit Juice', 'Seasonal & Specials', 55),
            ('Tender Coconut Water', 'Seasonal & Specials', 45),
            ('Nannari Sarbath', 'Seasonal & Specials', 40),
            ('Panagam (seasonal)', 'Seasonal & Specials', 35),
        ]
    },
    {
        'name': 'Hotspot',
        'desc': 'Classic Maggi, Hot Coffee, Fresh Tea & Bakery Treats',
        'items': [
            # Maggi
            ('Classic Maggi', 'Maggi', 40),
            # Drinks
            ('Coffee', 'Hot Drinks', 20),
            ('Tea', 'Hot Drinks', 15),
            # Biscuits & Bakery Items
            ('Oreo', 'Biscuits & Bakery', 30),
            ('Bourbon', 'Biscuits & Bakery', 30),
            ('Dark Fantasy', 'Biscuits & Bakery', 40),
            ('Cream Bun', 'Biscuits & Bakery', 20),
            ('Good Day', 'Biscuits & Bakery', 25),
            ('Hide & Seek', 'Biscuits & Bakery', 35),
            ('Happy Happy', 'Biscuits & Bakery', 15),
            ('Jam Bun', 'Biscuits & Bakery', 20),
        ]
    }
]

# Write to menu_seed.json
all_seed = []
for out in outlets_data:
    for name, cat, price in out['items']:
        all_seed.append({
            'outlet': out['name'],
            'category': cat,
            'name': name,
            'price': price,
            'image': '',
            'available': True
        })

base_dir = os.path.dirname(__file__)
seed_file = os.path.join(base_dir, 'menu_seed.json')
with open(seed_file, 'w', encoding='utf-8') as f:
    json.dump(all_seed, f, indent=2, ensure_ascii=False)
print(f'Successfully wrote {len(all_seed)} items to menu_seed.json')

# Update MySQL database
conn = mysql.connector.connect(
    host=os.getenv('DB_HOST', 'localhost'),
    port=int(os.getenv('DB_PORT', '3306')),
    user=os.getenv('DB_USER', 'root'),
    password=os.getenv('DB_PASSWORD', ''),
    database=os.getenv('DB_NAME', 'rec_canteen')
)
cursor = conn.cursor(dictionary=True)

# 1. Clear order_items and orders to avoid foreign key conflicts
cursor.execute('DELETE FROM order_items')
cursor.execute('DELETE FROM orders')

# 2. Clear menu_items
cursor.execute('DELETE FROM menu_items')

# 3. Synchronize outlets
cursor.execute('DELETE FROM outlets')
for out in outlets_data:
    cursor.execute('INSERT INTO outlets (name, description) VALUES (%s, %s)', (out['name'], out['desc']))
conn.commit()

# Read new outlet_ids
cursor.execute('SELECT outlet_id, name FROM outlets')
outlet_map = {row['name']: row['outlet_id'] for row in cursor.fetchall()}

# Insert new menu items
insert_sql = '''
INSERT INTO menu_items (outlet_id, name, category, price, image_url, is_available)
VALUES (%s, %s, %s, %s, %s, %s)
'''
rows_to_insert = []
for item in all_seed:
    oid = outlet_map[item['outlet']]
    rows_to_insert.append((
        oid,
        item['name'],
        item['category'],
        Decimal(str(item['price'])),
        '',
        True
    ))

cursor.executemany(insert_sql, rows_to_insert)
conn.commit()

# Verify counts per outlet
cursor.execute('''
SELECT o.name AS outlet_name, COUNT(m.menu_item_id) AS item_count
FROM outlets o
LEFT JOIN menu_items m ON m.outlet_id = o.outlet_id
GROUP BY o.outlet_id, o.name
ORDER BY o.outlet_id
''')
print('\nMySQL Outlets & Items Summary:')
total = 0
for r in cursor.fetchall():
    print(f"  {r['outlet_name']}: {r['item_count']} items")
    total += r['item_count']
print(f'\nTotal Menu Items in Database: {total}')

cursor.close()
conn.close()
