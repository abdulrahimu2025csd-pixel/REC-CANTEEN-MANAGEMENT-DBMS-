export interface FoodItem {
  id: string;
  name: string;
  category: string;
  price: number;
  aiPrompt: string;
  imageUrl: string;
  rating: number;
  outlet?: string;
  subCategory?: string;
  description?: string;
  prepTime?: string;
  isVeg?: boolean;
}

export interface CartItem {
  item: FoodItem;
  quantity: number;
}

export type CursorVariant = 'default' | 'hover' | 'button' | 'card' | 'hidden';

export interface CursorContextType {
  cursorVariant: CursorVariant;
  setCursorVariant: (variant: CursorVariant) => void;
  cursorText: string;
  setCursorText: (text: string) => void;
}
