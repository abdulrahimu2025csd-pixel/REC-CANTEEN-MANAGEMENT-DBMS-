import { InteractiveFoodOrdering } from './components/InteractiveFoodOrdering';

export function App() {
  return <InteractiveFoodOrdering />;
}

export default App;
