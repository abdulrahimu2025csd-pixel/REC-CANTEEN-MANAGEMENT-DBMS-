import React, { useState, useRef } from 'react';
import { FoodItem, CartItem, CursorVariant } from '../types';
import { CustomCursor } from './CustomCursor';
import { HeroSection } from './HeroSection';
import { MenuGrid } from './MenuGrid';
import { CartDrawer } from './CartDrawer';
import { ShoppingBag, Sparkles, ChefHat, ArrowLeft } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const InteractiveFoodOrdering: React.FC = () => {
  const [cursorVariant, setCursorVariant] = useState<CursorVariant>('default');
  const [cursorText, setCursorText] = useState<string>('');
  const [isGliding, setIsGliding] = useState<boolean>(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  
  // View mode: 'welcome' (hero welcoming view) or 'menu' (full animated catalog view)
  const [viewMode, setViewMode] = useState<'welcome' | 'menu'>('welcome');

  const catalogRef = useRef<HTMLDivElement>(null);

  // Trigger cool transition from welcoming to menu catalog
  const handleStartPurchasing = () => {
    setIsGliding(true);
    
    // Switch to menu view with cool animation
    setTimeout(() => {
      setViewMode('menu');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 400);

    setTimeout(() => {
      setIsGliding(false);
    }, 1800);
  };

  const handleReturnToWelcome = () => {
    setViewMode('welcome');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAddToCart = (item: FoodItem) => {
    setCart((prevCart) => {
      const existing = prevCart.find((ci) => ci.item.id === item.id);
      if (existing) {
        return prevCart.map((ci) =>
          ci.item.id === item.id ? { ...ci, quantity: ci.quantity + 1 } : ci
        );
      }
      return [...prevCart, { item, quantity: 1 }];
    });
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCart((prevCart) => {
      return prevCart
        .map((ci) => {
          if (ci.item.id === id) {
            const nextQty = ci.quantity + delta;
            return nextQty > 0 ? { ...ci, quantity: nextQty } : null;
          }
          return ci;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const handleClearCart = () => setCart([]);

  const totalCartCount = cart.reduce((acc, i) => acc + i.quantity, 0);
  const cartItemIds = new Set(cart.map((ci) => ci.item.id));

  return (
    <div className="relative min-h-screen bg-purple-50/30 text-purple-950 selection:bg-purple-600 selection:text-white custom-cursor-active overflow-x-hidden">
      {/* 1. Custom Purple Image Cursor */}
      <CustomCursor variant={cursorVariant} text={cursorText} />

      {/* Navigation Header in Crisp White with Purple Accents */}
      <header className="sticky top-0 z-40 backdrop-blur-md bg-white/90 border-b border-purple-100 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          {/* Logo Branding */}
          <div
            className="flex items-center gap-3 cursor-pointer"
            onClick={handleReturnToWelcome}
            onMouseEnter={() => {
              setCursorVariant('hover');
              setCursorText('WELCOME');
            }}
            onMouseLeave={() => {
              setCursorVariant('default');
              setCursorText('');
            }}
          >
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-700 via-purple-600 to-violet-600 flex items-center justify-center text-white font-black shadow-md shadow-purple-600/25">
              <ChefHat className="w-6 h-6 stroke-[2.5]" />
            </div>
            <div>
              <span className="font-extrabold text-lg tracking-tight text-purple-950 block leading-none">
                REC Canteen
              </span>
              <span className="text-[10px] font-bold uppercase tracking-wider text-purple-600 block mt-1">
                Campus Food Portal
              </span>
            </div>
          </div>

          {/* Quick Actions & Cart Trigger */}
          <div className="flex items-center gap-3 sm:gap-4">
            {viewMode === 'menu' && (
              <button
                onClick={handleReturnToWelcome}
                onMouseEnter={() => setCursorVariant('hover')}
                onMouseLeave={() => setCursorVariant('default')}
                className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-purple-100/70 hover:bg-purple-100 text-purple-800 text-xs font-bold transition cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Welcome View</span>
              </button>
            )}

            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-purple-50 border border-purple-200 text-xs text-purple-700 font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
              <span>Kitchens Live</span>
            </div>

            <button
              onClick={() => setIsCartOpen(true)}
              onMouseEnter={() => {
                setCursorVariant('button');
                setCursorText('CART');
              }}
              onMouseLeave={() => {
                setCursorVariant('default');
                setCursorText('');
              }}
              className="relative p-3 rounded-2xl bg-white border border-purple-200 hover:border-purple-400 text-purple-950 transition-all shadow-xs group cursor-pointer"
              aria-label="View Cart"
            >
              <ShoppingBag className="w-5 h-5 group-hover:text-purple-600 transition" />
              {totalCartCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-purple-700 text-white font-black text-[11px] flex items-center justify-center shadow-md shadow-purple-700/30 animate-bounce">
                  {totalCartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Animated Container */}
      <AnimatePresence mode="wait">
        {viewMode === 'welcome' ? (
          /* Welcoming Entrance Screen */
          <motion.div
            key="welcome-view"
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, y: -40, filter: 'blur(4px)' }}
            transition={{ duration: 0.4 }}
          >
            <HeroSection
              onStartPurchasing={handleStartPurchasing}
              setCursorVariant={setCursorVariant}
              setCursorText={setCursorText}
              isGliding={isGliding}
            />
          </motion.div>
        ) : (
          /* Catalog & Menu Grid with Top-to-Bottom Entrance Fly-In */
          <motion.div
            key="menu-view"
            initial={{ opacity: 0, y: -60 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 40 }}
            transition={{ type: 'spring', damping: 20, stiffness: 100 }}
            ref={catalogRef}
          >
            <MenuGrid
              onAddToCart={handleAddToCart}
              setCursorVariant={setCursorVariant}
              setCursorText={setCursorText}
              cartItemIds={cartItemIds}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Slide-out Cart Drawer in Purple & White */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onClearCart={handleClearCart}
        setCursorVariant={setCursorVariant}
      />

      {/* Footer in Clean Purple & White */}
      <footer className="border-t border-purple-100 bg-white/70 py-10 mt-20 text-center text-xs text-purple-800/80">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="font-semibold">&copy; {new Date().getFullYear()} REC Canteen Management System. All rights reserved.</p>
          <div className="flex items-center gap-2 text-purple-700 font-bold">
            <Sparkles className="w-3.5 h-3.5 text-purple-600" />
            <span>AI Food Visualization powered by Pollinations AI</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default InteractiveFoodOrdering;
