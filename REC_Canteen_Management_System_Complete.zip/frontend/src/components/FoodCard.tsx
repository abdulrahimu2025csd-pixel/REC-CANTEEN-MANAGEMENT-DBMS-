import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Star, Clock, Plus, Check, Sparkles, Image as ImageIcon } from 'lucide-react';
import { FoodItem, CursorVariant } from '../types';
import { getPollinationsUrl } from '../data/foodItems';

interface FoodCardProps {
  item: FoodItem;
  onAddToCart: (item: FoodItem) => void;
  setCursorVariant: (variant: CursorVariant) => void;
  setCursorText: (text: string) => void;
  isInCart?: boolean;
}

export const FoodCard: React.FC<FoodCardProps> = ({
  item,
  onAddToCart,
  setCursorVariant,
  setCursorText,
  isInCart = false,
}) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);
  const [useFallback, setUseFallback] = useState(false);
  const [isAddedAnim, setIsAddedAnim] = useState(false);

  // Attempt AI generated image via Pollinations AI, fall back to high-res Unsplash if needed
  const activeImageSrc = useFallback
    ? item.imageUrl
    : getPollinationsUrl(item.aiPrompt);

  const handleImageError = () => {
    if (!useFallback) {
      setUseFallback(true);
      setImageLoaded(false);
    } else {
      setImageError(true);
      setImageLoaded(true);
    }
  };

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(item);
    setIsAddedAnim(true);
    setTimeout(() => setIsAddedAnim(false), 800);
  };

  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: -80 },
        visible: {
          opacity: 1,
          y: 0,
          transition: {
            type: 'spring',
            damping: 18,
            stiffness: 90,
          },
        },
      }}
      whileHover={{ y: -6, transition: { duration: 0.2 } }}
      onMouseEnter={() => {
        setCursorVariant('card');
        setCursorText('ADD ₹' + item.price);
      }}
      onMouseLeave={() => {
        setCursorVariant('default');
        setCursorText('');
      }}
      className="group relative flex flex-col rounded-3xl bg-white border border-purple-100 hover:border-purple-300 transition-all duration-300 overflow-hidden shadow-md shadow-purple-500/5 hover:shadow-xl hover:shadow-purple-500/15"
    >
      {/* Food Image Container with 16:10 aspect ratio */}
      <div className="relative aspect-[16/10] w-full overflow-hidden bg-purple-50">
        {/* Responsive Skeleton Loader in Soft Lilac (animate-pulse) */}
        {!imageLoaded && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-purple-100/70 animate-pulse z-10">
            <ImageIcon className="w-8 h-8 text-purple-300 mb-2" />
            <span className="text-[11px] font-bold tracking-wide text-purple-600 uppercase flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-purple-500" /> Generating AI Visual...
            </span>
          </div>
        )}

        {/* Dynamic Image */}
        {!imageError ? (
          <img
            src={activeImageSrc}
            alt={item.name}
            loading="lazy"
            onLoad={() => setImageLoaded(true)}
            onError={handleImageError}
            className={`w-full h-full object-cover object-center group-hover:scale-105 transition-all duration-500 ${
              imageLoaded ? 'opacity-100 blur-0' : 'opacity-0 blur-sm'
            }`}
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-purple-50 text-purple-600 p-4 text-center">
            <Sparkles className="w-8 h-8 text-purple-400 mb-2" />
            <span className="text-sm font-bold">{item.name}</span>
          </div>
        )}

        {/* Gradient Overlay for Text Legibility */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/15 pointer-events-none" />

        {/* Category & Outlet Badges */}
        <div className="absolute top-3 left-3 flex flex-wrap gap-1.5 z-20">
          <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-white/95 backdrop-blur-md text-purple-900 border border-purple-200 shadow-sm">
            {item.outlet || item.category}
          </span>
          {item.subCategory && item.subCategory !== item.outlet && (
            <span className="px-2 py-1 rounded-full text-[10px] font-semibold bg-purple-950/75 backdrop-blur-md text-purple-100 border border-purple-400/30 shadow-sm">
              {item.subCategory}
            </span>
          )}
        </div>

        {/* Rating Badge */}
        <div className="absolute top-3 right-3 flex items-center gap-2 z-20">
          <div className="px-2.5 py-1 rounded-full bg-white/95 backdrop-blur-md border border-purple-200 flex items-center gap-1 shadow-sm">
            <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
            <span className="text-xs font-black text-purple-950">{item.rating}</span>
          </div>
        </div>

        {/* AI Tag indicator in White / Lilac */}
        <div className="absolute bottom-2.5 left-3 flex items-center gap-1 text-[10px] text-white font-bold z-20 drop-shadow-sm">
          <Sparkles className="w-3 h-3 text-amber-300" />
          <span>AI Food Visual</span>
        </div>
      </div>

      {/* Card Content & Details in Purple & White */}
      <div className="flex flex-col flex-1 p-5 bg-white">
        <div className="flex items-start justify-between gap-2 mb-2">
          <h3 className="text-base sm:text-lg font-black text-purple-950 group-hover:text-purple-700 transition-colors line-clamp-1">
            {item.name}
          </h3>
          <span className="shrink-0 text-base sm:text-lg font-extrabold text-purple-700">
            ₹{item.price}
          </span>
        </div>

        {item.description && (
          <p className="text-xs text-purple-900/70 font-medium line-clamp-2 mb-4 leading-relaxed flex-1">
            {item.description}
          </p>
        )}

        <div className="flex items-center justify-between pt-3 border-t border-purple-100 mt-auto">
          {item.prepTime && (
            <div className="flex items-center gap-1 text-xs text-purple-700 font-semibold">
              <Clock className="w-3.5 h-3.5 text-purple-400" />
              <span>{item.prepTime}</span>
            </div>
          )}

          {/* Add to Cart CTA in Royal Purple */}
          <motion.button
            onClick={handleAdd}
            whileTap={{ scale: 0.92 }}
            className={`relative inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer ${
              isAddedAnim || isInCart
                ? 'bg-emerald-600 text-white shadow-emerald-500/20'
                : 'bg-gradient-to-r from-purple-700 via-purple-600 to-violet-600 hover:from-purple-800 hover:to-violet-700 text-white shadow-purple-600/20'
            }`}
          >
            {isAddedAnim ? (
              <>
                <Check className="w-3.5 h-3.5 stroke-[3]" /> Added!
              </>
            ) : isInCart ? (
              <>
                <Check className="w-3.5 h-3.5 stroke-[3]" /> In Cart (+1)
              </>
            ) : (
              <>
                <Plus className="w-3.5 h-3.5 stroke-[3]" /> Add to Order
              </>
            )}
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
};
