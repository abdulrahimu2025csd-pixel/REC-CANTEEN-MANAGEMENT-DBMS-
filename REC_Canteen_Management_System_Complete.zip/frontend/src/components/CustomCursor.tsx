import React, { useEffect, useState } from 'react';
import { motion, useMotionValue, useSpring } from 'motion/react';
import { Utensils, Sparkles, Plus, ArrowUpRight } from 'lucide-react';
import { CursorVariant } from '../types';

interface CustomCursorProps {
  variant: CursorVariant;
  text?: string;
}

export const CustomCursor: React.FC<CustomCursorProps> = ({ variant, text }) => {
  const [isVisible, setIsVisible] = useState(false);
  const [isTouchDevice, setIsTouchDevice] = useState(false);

  // Mouse coordinates with high-precision motion values
  const mouseX = useMotionValue(-100);
  const mouseY = useMotionValue(-100);

  // Ultra-responsive spring physics for zero-lag follow
  const springConfig = { damping: 28, stiffness: 450, mass: 0.2 };
  const cursorX = useSpring(mouseX, springConfig);
  const cursorY = useSpring(mouseY, springConfig);

  // Slightly softer trailing spring for the ambient highlight ring
  const ringSpringConfig = { damping: 22, stiffness: 220, mass: 0.5 };
  const ringX = useSpring(mouseX, ringSpringConfig);
  const ringY = useSpring(mouseY, ringSpringConfig);

  useEffect(() => {
    // Detect touch-only devices where custom mouse cursors would obstruct the UI
    if (window.matchMedia('(pointer: coarse)').matches) {
      setIsTouchDevice(true);
      return;
    }

    const handleMouseMove = (e: MouseEvent) => {
      mouseX.set(e.clientX);
      mouseY.set(e.clientY);
      if (!isVisible) setIsVisible(true);
    };

    const handleMouseLeave = () => setIsVisible(false);
    const handleMouseEnter = () => setIsVisible(true);

    window.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseleave', handleMouseLeave);
    document.addEventListener('mouseenter', handleMouseEnter);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('mouseenter', handleMouseEnter);
    };
  }, [isVisible, mouseX, mouseY]);

  if (isTouchDevice || !isVisible || variant === 'hidden') {
    return null;
  }

  // Determine trailing ring size and scale based on hovered element
  const getRingVariants = () => {
    switch (variant) {
      case 'button':
        return {
          scale: 1.8,
          borderColor: 'rgba(124, 58, 237, 0.85)',
          backgroundColor: 'rgba(237, 233, 254, 0.5)',
        };
      case 'card':
        return {
          scale: 1.5,
          borderColor: 'rgba(147, 51, 234, 0.7)',
          backgroundColor: 'rgba(243, 232, 255, 0.4)',
        };
      case 'hover':
        return {
          scale: 1.6,
          borderColor: 'rgba(168, 85, 247, 0.75)',
          backgroundColor: 'rgba(245, 243, 255, 0.45)',
        };
      default:
        return {
          scale: 1,
          borderColor: 'rgba(192, 132, 252, 0.4)',
          backgroundColor: 'transparent',
        };
    }
  };

  return (
    <div className="fixed inset-0 pointer-events-none z-[9999] overflow-hidden">
      {/* Outer ambient trailing highlight ring */}
      <motion.div
        className="absolute top-0 left-0 w-10 h-10 -ml-5 -mt-5 rounded-full border border-purple-400/50 backdrop-blur-[1px] pointer-events-none"
        style={{
          x: ringX,
          y: ringY,
        }}
        animate={getRingVariants()}
        transition={{ type: 'spring', damping: 20, stiffness: 300 }}
      />

      {/* Main floating custom image/asset cursor */}
      <motion.div
        className="absolute top-0 left-0 -ml-3.5 -mt-3.5 flex items-center justify-center pointer-events-none"
        style={{
          x: cursorX,
          y: cursorY,
        }}
        animate={{
          scale: variant === 'button' ? 0.85 : variant === 'hover' ? 1.25 : 1,
          rotate: variant === 'card' ? 15 : 0,
        }}
        transition={{ type: 'spring', damping: 25, stiffness: 400 }}
      >
        <div className="relative flex items-center justify-center w-7 h-7 rounded-full bg-gradient-to-tr from-purple-700 via-purple-600 to-violet-500 text-white shadow-lg shadow-purple-600/35 border border-purple-300/80">
          {variant === 'card' ? (
            <Plus className="w-3.5 h-3.5 stroke-[3]" />
          ) : variant === 'button' ? (
            <ArrowUpRight className="w-3.5 h-3.5 stroke-[3]" />
          ) : (
            <Utensils className="w-3.5 h-3.5 stroke-[2.5]" />
          )}

          {/* Micro sparkle badge on hover */}
          {variant !== 'default' && (
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-amber-400 text-purple-950 flex items-center justify-center shadow-xs"
            >
              <Sparkles className="w-1.5 h-1.5" />
            </motion.div>
          )}
        </div>

        {/* Optional trailing tooltip text (e.g. "START", "ADD ₹189") */}
        {text && (
          <motion.span
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            className="absolute left-9 top-1/2 -translate-y-1/2 px-2.5 py-1 rounded-lg text-[10px] font-extrabold tracking-wider uppercase bg-purple-950/90 text-purple-200 border border-purple-400/40 whitespace-nowrap shadow-md backdrop-blur-xs"
          >
            {text}
          </motion.span>
        )}
      </motion.div>
    </div>
  );
};
