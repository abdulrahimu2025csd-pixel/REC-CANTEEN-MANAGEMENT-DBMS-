import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, SlidersHorizontal, Sparkles } from 'lucide-react';
import { FoodItem, CursorVariant } from '../types';
import { CATEGORIES, FOOD_ITEMS } from '../data/foodItems';
import { FoodCard } from './FoodCard';

interface MenuGridProps {
  onAddToCart: (item: FoodItem) => void;
  setCursorVariant: (variant: CursorVariant) => void;
  setCursorText: (text: string) => void;
  cartItemIds: Set<string>;
}

export const MenuGrid: React.FC<MenuGridProps> = ({
  onAddToCart,
  setCursorVariant,
  setCursorText,
  cartItemIds,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredItems = useMemo(() => {
    return FOOD_ITEMS.filter((item) => {
      const matchesCategory =
        selectedCategory === 'All' ||
        item.category === selectedCategory ||
        item.outlet === selectedCategory ||
        item.subCategory === selectedCategory;
      const matchesSearch =
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (item.subCategory && item.subCategory.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (item.description && item.description.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (item.outlet && item.outlet.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCategory && matchesSearch;
    });
  }, [selectedCategory, searchQuery]);

  // Framer Motion staggered entrance container
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.08,
        delayChildren: 0.1,
      },
    },
  };

  return (
    <section id="menu-catalog" className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      {/* Section Header in Purple & White */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10 pb-6 border-b border-purple-200/80">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-100 text-purple-800 text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5 text-purple-600" />
            <span>Campus Dining Hub</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-purple-950 tracking-tight">
            Explore Canteen Delicacies
          </h2>
          <p className="text-purple-700/80 text-sm mt-1 font-medium">
            Server-verified rates &bull; 8 Outlets &bull; Illustrative AI food previews
          </p>
        </div>

        {/* Live Search Input in Crisp White with Purple Accents */}
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-purple-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search pizza, momos, burger..."
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white border border-purple-200 focus:border-purple-600 focus:ring-2 focus:ring-purple-200 text-purple-950 text-sm placeholder-purple-400 outline-none transition-all shadow-xs"
            onMouseEnter={() => {
              setCursorVariant('hover');
              setCursorText('TYPE');
            }}
            onMouseLeave={() => {
              setCursorVariant('default');
              setCursorText('');
            }}
          />
        </div>
      </div>

      {/* Category Pills Navigation in Purple & White */}
      <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-10 no-scrollbar">
        <SlidersHorizontal className="w-4 h-4 text-purple-400 shrink-0 ml-1 mr-2" />
        {CATEGORIES.map((cat) => {
          const isActive = selectedCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              onMouseEnter={() => {
                setCursorVariant('hover');
                setCursorText(cat.substring(0, 5));
              }}
              onMouseLeave={() => {
                setCursorVariant('default');
                setCursorText('');
              }}
              className={`relative px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all duration-200 cursor-pointer ${
                isActive
                  ? 'bg-purple-700 text-white shadow-md shadow-purple-600/30'
                  : 'bg-white text-purple-800 hover:text-purple-950 hover:bg-purple-50 border border-purple-200 shadow-xs'
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* Dynamic Staggered Menu Grid (Top-to-Bottom Fly-in) */}
      <AnimatePresence mode="wait">
        <motion.div
          key={selectedCategory + searchQuery}
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8"
        >
          {filteredItems.map((item) => (
            <FoodCard
              key={item.id}
              item={item}
              onAddToCart={onAddToCart}
              setCursorVariant={setCursorVariant}
              setCursorText={setCursorText}
              isInCart={cartItemIds.has(item.id)}
            />
          ))}
        </motion.div>
      </AnimatePresence>

      {/* Empty State */}
      {filteredItems.length === 0 && (
        <div className="py-20 text-center flex flex-col items-center justify-center bg-white rounded-3xl border border-purple-100 shadow-sm p-8">
          <Sparkles className="w-12 h-12 text-purple-300 mb-4" />
          <p className="text-purple-950 font-bold text-lg">
            No dishes found matching your search.
          </p>
          <button
            onClick={() => {
              setSelectedCategory('All');
              setSearchQuery('');
            }}
            className="mt-4 px-6 py-2 rounded-xl bg-purple-700 text-white font-bold text-xs hover:bg-purple-800 transition cursor-pointer shadow-sm"
          >
            Clear Filters
          </button>
        </div>
      )}
    </section>
  );
};
