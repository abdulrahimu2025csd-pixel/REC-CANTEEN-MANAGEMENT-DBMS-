import React, { useRef } from 'react';
import { motion, useMotionValue, useSpring } from 'motion/react';
import { ShoppingBag, ArrowDown, Sparkles, Zap, Utensils, Award, HeartHandshake } from 'lucide-react';
import { AnimatedMascot } from './AnimatedMascot';
import { CursorVariant } from '../types';

interface HeroSectionProps {
  onStartPurchasing: () => void;
  setCursorVariant: (variant: CursorVariant) => void;
  setCursorText: (text: string) => void;
  isGliding: boolean;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onStartPurchasing,
  setCursorVariant,
  setCursorText,
  isGliding,
}) => {
  const buttonRef = useRef<HTMLButtonElement>(null);

  // Magnetic hover effect values
  const btnX = useMotionValue(0);
  const btnY = useMotionValue(0);
  const springX = useSpring(btnX, { damping: 15, stiffness: 200 });
  const springY = useSpring(btnY, { damping: 15, stiffness: 200 });

  const handleMouseMove = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (!buttonRef.current) return;
    const rect = buttonRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const distanceX = (e.clientX - centerX) * 0.35;
    const distanceY = (e.clientY - centerY) * 0.35;
    btnX.set(distanceX);
    btnY.set(distanceY);
  };

  const handleMouseLeave = () => {
    btnX.set(0);
    btnY.set(0);
    setCursorVariant('default');
    setCursorText('');
  };

  return (
    <section className="relative min-h-[90vh] flex flex-col justify-center items-center text-center px-4 sm:px-6 lg:px-8 pt-10 pb-24 overflow-hidden bg-purple-dots">
      {/* Ambient background purple & violet glow accents */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[380px] bg-gradient-to-tr from-purple-300/30 via-violet-200/40 to-fuchsia-200/20 rounded-full blur-[130px] pointer-events-none" />
      <div className="absolute top-16 left-12 w-80 h-80 bg-purple-200/40 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-16 right-12 w-96 h-96 bg-indigo-200/30 rounded-full blur-[110px] pointer-events-none" />

      {/* Welcoming Top Banner & Feature Chips in Clean White & Purple */}
      <div className="flex flex-wrap items-center justify-center gap-3 mb-6">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/90 border border-purple-200 text-purple-900 text-xs font-bold shadow-sm shadow-purple-500/10 backdrop-blur-md"
        >
          <HeartHandshake className="w-4 h-4 text-purple-600" />
          <span>Welcome to REC Canteen</span>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/90 border border-purple-200 text-purple-700 text-xs font-bold shadow-sm shadow-purple-500/10 backdrop-blur-md"
        >
          <Zap className="w-3.5 h-3.5 text-purple-600 fill-purple-600" />
          <span>8 Live Campus Outlets</span>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-100 text-purple-800 border border-purple-200 text-xs font-bold shadow-xs backdrop-blur-md"
        >
          <Sparkles className="w-3.5 h-3.5 text-purple-600" />
          <span>AI Food Visuals</span>
        </motion.div>
      </div>

      {/* Hero Headline in Royal Purple & Deep Indigo */}
      <motion.h1
        initial={{ opacity: 0, y: 25 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
        className="text-4xl sm:text-6xl md:text-7xl font-black tracking-tight text-purple-950 max-w-4xl leading-[1.1] mb-6"
      >
        Big Cravings. <br />
        <span className="bg-gradient-to-r from-purple-700 via-violet-600 to-indigo-600 bg-clip-text text-transparent">
          Zero Campus Queues.
        </span>
      </motion.h1>

      {/* Welcoming Subheading */}
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.28 }}
        className="text-purple-800/80 text-base sm:text-xl max-w-2xl mb-10 font-medium leading-relaxed"
      >
        Welcome! Order your favourite pizzas, sizzling noodles, sandwiches, and chilled shakes directly from your screen with live kitchen updates and instant QR pickup receipts.
      </motion.p>

      {/* Whimsical Mascot Runner in Purple & White */}
      <motion.div
        initial={{ opacity: 0, scale: 0.85 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, delay: 0.35 }}
        className="mb-10"
      >
        <AnimatedMascot isGliding={isGliding} />
      </motion.div>

      {/* Elevated Hero CTA Button ("Start Purchasing") in Royal Purple & White */}
      <motion.div
        style={{ x: springX, y: springY }}
        className="relative group z-10"
      >
        {/* Radiant Ambient Purple Glow Behind Button */}
        <div className="absolute -inset-2 bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-600 rounded-3xl blur-xl opacity-60 group-hover:opacity-100 transition duration-300 animate-pulse-subtle" />

        {/* 3D Elevated Button with tactile press and crisp white text */}
        <motion.button
          ref={buttonRef}
          onClick={onStartPurchasing}
          onMouseMove={handleMouseMove}
          onMouseEnter={() => {
            setCursorVariant('button');
            setCursorText('START');
          }}
          onMouseLeave={handleMouseLeave}
          whileHover={{ scale: 1.04 }}
          whileTap={{ scale: 0.95, y: 3 }}
          className="relative inline-flex items-center gap-4 px-9 sm:px-12 py-4.5 sm:py-5 rounded-2xl text-white font-extrabold text-lg sm:text-xl bg-gradient-to-b from-purple-600 via-purple-700 to-indigo-800 shadow-[0_8px_0_#4c1d95,0_18px_30px_rgba(124,58,237,0.35)] active:shadow-[0_2px_0_#4c1d95,0_6px_12px_rgba(124,58,237,0.25)] transition-all duration-150 border-t border-purple-300/60 active:translate-y-1 cursor-pointer"
        >
          <ShoppingBag className="w-6 h-6 stroke-[2.5]" />
          <span>Start Purchasing</span>
          <motion.span
            animate={{ y: [0, 4, 0] }}
            transition={{ repeat: Infinity, duration: 1.4, ease: 'easeInOut' }}
          >
            <ArrowDown className="w-5 h-5 stroke-[3]" />
          </motion.span>
        </motion.button>
      </motion.div>

      {/* Trust Micro-Metrics in Purple & White */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.45 }}
        className="flex items-center gap-6 mt-12 text-xs sm:text-sm text-purple-700 font-semibold"
      >
        <span className="flex items-center gap-1.5">
          <Award className="w-4 h-4 text-purple-600" /> Student Friendly &bull; No Signup
        </span>
        <span className="w-1.5 h-1.5 rounded-full bg-purple-300" />
        <span className="flex items-center gap-1.5">
          <Utensils className="w-4 h-4 text-violet-600" /> 8 Verified Campus Kitchens
        </span>
      </motion.div>
    </section>
  );
};
