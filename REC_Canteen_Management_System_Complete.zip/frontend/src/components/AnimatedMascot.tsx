import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Pizza, Flame } from 'lucide-react';

interface AnimatedMascotProps {
  isGliding?: boolean;
  className?: string;
}

export const AnimatedMascot: React.FC<AnimatedMascotProps> = ({ isGliding = false, className = '' }) => {
  return (
    <motion.div
      className={`relative inline-flex flex-col items-center select-none ${className}`}
      animate={
        isGliding
          ? {
              y: [0, 45, -15, 0],
              x: [0, 20, -10, 0],
              rotate: [0, -8, 8, -3, 0],
              scale: [1, 1.15, 0.95, 1],
            }
          : {
              y: [0, -6, 0],
              rotate: [-1, 1, -1],
            }
      }
      transition={{
        duration: isGliding ? 1.4 : 3,
        repeat: isGliding ? 0 : Infinity,
        ease: 'easeInOut',
      }}
    >
      {/* Glow aura */}
      <div className="absolute -inset-2 bg-gradient-to-r from-purple-500/20 via-violet-500/25 to-indigo-500/20 rounded-full blur-xl pointer-events-none" />

      {/* Mascot Card / Passport Badge Container in Crisp White & Purple */}
      <div className="relative px-5 py-3.5 rounded-2xl bg-white/95 border border-purple-200 shadow-xl shadow-purple-500/10 backdrop-blur-md flex items-center gap-3.5">
        {/* Animated Mascot Character Face in Purple Gradient */}
        <div className="relative w-12 h-12 rounded-xl bg-gradient-to-tr from-purple-700 via-purple-600 to-violet-500 p-0.5 shadow-md shadow-purple-600/30">
          <div className="w-full h-full rounded-[10px] bg-purple-950 flex items-center justify-center relative overflow-hidden">
            {/* Chef Hat & Ears Graphic */}
            <svg
              className="w-8 h-8 text-purple-200"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M6 13.87A4 4 0 0 1 7.41 6a5.11 5.11 0 0 1 1.05-1.54 5 5 0 0 1 7.08 0A5.11 5.11 0 0 1 16.59 6 4 4 0 0 1 18 13.87V21H6Z" />
              <line x1="6" y1="17" x2="18" y2="17" />
            </svg>

            {/* Winking Eyes and Smile */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pt-2">
              <div className="flex gap-2">
                <motion.div
                  animate={{ scaleY: [1, 0.1, 1] }}
                  transition={{ repeat: Infinity, duration: 3.5, repeatDelay: 2 }}
                  className="w-1.5 h-1.5 bg-amber-300 rounded-full"
                />
                <div className="w-1.5 h-1.5 bg-amber-300 rounded-full" />
              </div>
              {/* Joyful mouth eating */}
              <motion.div
                animate={{ scaleX: [1, 1.3, 1], scaleY: [1, 1.4, 1] }}
                transition={{ repeat: Infinity, duration: 1.2 }}
                className="w-2.5 h-1.5 border-b-2 border-violet-300 rounded-full mt-0.5"
              />
            </div>
          </div>

          {/* Running crumbs or steam particles */}
          <motion.div
            animate={{
              y: [-2, -8, -12],
              x: [-4, -8, -12],
              opacity: [1, 0.6, 0],
              scale: [0.8, 1.2, 0.5],
            }}
            transition={{ repeat: Infinity, duration: 1.5, ease: 'easeOut' }}
            className="absolute -top-1 -right-1 text-purple-400"
          >
            <Sparkles className="w-3 h-3" />
          </motion.div>
        </div>

        {/* Passport / Canteen Runner Info in Purple & White */}
        <div className="flex flex-col text-left">
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-black tracking-wider text-purple-900 uppercase">
              REC Foodie Bot
            </span>
            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-bold bg-purple-100 text-purple-700 border border-purple-200">
              <Flame className="w-2.5 h-2.5 mr-0.5 inline text-purple-600" />
              Ready
            </span>
          </div>
          <p className="text-[11px] text-purple-700/80 flex items-center gap-1 font-semibold mt-0.5">
            <Pizza className="w-3 h-3 text-purple-500" /> Gliding to kitchen
          </p>
        </div>
      </div>
    </motion.div>
  );
};
