import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ShoppingBag, Plus, Minus, Trash2, ArrowRight, QrCode, CheckCircle2 } from 'lucide-react';
import { CartItem, CursorVariant } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onClearCart: () => void;
  setCursorVariant: (variant: CursorVariant) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onClearCart,
  setCursorVariant,
}) => {
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');

  const subtotal = cart.reduce(
    (acc, item) => acc + item.item.price * item.quantity,
    0
  );
  const packagingFee = subtotal > 0 ? 10 : 0;
  const total = subtotal + packagingFee;

  const handleCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerPhone) return;
    setOrderPlaced(true);
  };

  const handleReset = () => {
    setOrderPlaced(false);
    setCustomerName('');
    setCustomerPhone('');
    onClearCart();
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[1000] flex justify-end">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-purple-950/40 backdrop-blur-xs"
          />

          {/* Drawer Body in Crisp White & Purple */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 220 }}
            className="relative w-full max-w-md bg-white border-l border-purple-200 text-purple-950 h-full flex flex-col shadow-2xl z-10"
          >
            {/* Header */}
            <div className="p-5 border-b border-purple-100 flex items-center justify-between bg-purple-50/50">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-purple-700 text-white flex items-center justify-center shadow-xs">
                  <ShoppingBag className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-purple-950">Your Canteen Order</h3>
                  <p className="text-[11px] font-semibold text-purple-700">Counter Pickup</p>
                </div>
                <span className="ml-2 px-2.5 py-0.5 rounded-full text-xs font-black bg-purple-100 text-purple-800 border border-purple-200">
                  {cart.reduce((n, i) => n + i.quantity, 0)} items
                </span>
              </div>
              <button
                onClick={onClose}
                onMouseEnter={() => setCursorVariant('hover')}
                onMouseLeave={() => setCursorVariant('default')}
                className="p-2 rounded-xl text-purple-500 hover:text-purple-950 hover:bg-purple-100/70 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content / Items */}
            {!orderPlaced ? (
              <>
                <div className="flex-1 overflow-y-auto p-5 space-y-4">
                  {cart.length === 0 ? (
                    <div className="py-20 text-center flex flex-col items-center justify-center">
                      <div className="w-16 h-16 rounded-full bg-purple-50 flex items-center justify-center text-purple-300 mb-3 border border-purple-100">
                        <ShoppingBag className="w-8 h-8" />
                      </div>
                      <p className="text-purple-950 font-bold text-sm">
                        Your canteen bag is currently empty.
                      </p>
                      <p className="text-purple-700/80 text-xs mt-1">
                        Select mouth-watering items from the menu to get started!
                      </p>
                    </div>
                  ) : (
                    cart.map(({ item, quantity }) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between p-3.5 rounded-2xl bg-purple-50/50 border border-purple-100 gap-3 shadow-xs"
                      >
                        <div className="flex-1 min-w-0">
                          <h4 className="text-sm font-bold text-purple-950 truncate">
                            {item.name}
                          </h4>
                          <p className="text-xs text-purple-700/80 font-medium">
                            ₹{item.price} each &bull; <span className="text-purple-800 font-bold">{item.category}</span>
                          </p>
                        </div>

                        {/* Quantity Controls */}
                        <div className="flex items-center gap-1.5 bg-white border border-purple-200 rounded-xl p-1 shadow-xs">
                          <button
                            onClick={() => onUpdateQuantity(item.id, -1)}
                            className="p-1 rounded-lg text-purple-600 hover:text-purple-950 hover:bg-purple-100 transition cursor-pointer"
                          >
                            {quantity === 1 ? (
                              <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                            ) : (
                              <Minus className="w-3.5 h-3.5" />
                            )}
                          </button>
                          <span className="text-xs font-black w-4 text-center text-purple-950">
                            {quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQuantity(item.id, 1)}
                            className="p-1 rounded-lg text-purple-600 hover:text-purple-950 hover:bg-purple-100 transition cursor-pointer"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <span className="text-sm font-black text-purple-700 min-w-[50px] text-right">
                          ₹{item.price * quantity}
                        </span>
                      </div>
                    ))
                  )}

                  {cart.length > 0 && (
                    <form onSubmit={handleCheckout} className="pt-4 border-t border-purple-100 space-y-3">
                      <h4 className="text-xs font-black uppercase tracking-wider text-purple-900">
                        Student Pickup Information
                      </h4>
                      <div>
                        <input
                          type="text"
                          required
                          value={customerName}
                          onChange={(e) => setCustomerName(e.target.value)}
                          placeholder="Full Name (e.g. Rahul Sharma)"
                          className="w-full px-3.5 py-2.5 rounded-xl bg-purple-50/40 border border-purple-200 focus:border-purple-600 text-xs text-purple-950 placeholder-purple-400 outline-none"
                        />
                      </div>
                      <div>
                        <input
                          type="tel"
                          required
                          value={customerPhone}
                          onChange={(e) => setCustomerPhone(e.target.value)}
                          placeholder="Phone Number (10 digits)"
                          className="w-full px-3.5 py-2.5 rounded-xl bg-purple-50/40 border border-purple-200 focus:border-purple-600 text-xs text-purple-950 placeholder-purple-400 outline-none"
                        />
                      </div>
                    </form>
                  )}
                </div>

                {/* Footer Totals & Checkout Button */}
                {cart.length > 0 && (
                  <div className="p-5 border-t border-purple-100 bg-purple-50/30 space-y-3">
                    <div className="flex justify-between text-xs text-purple-800/80 font-medium">
                      <span>Subtotal</span>
                      <span>₹{subtotal}</span>
                    </div>
                    <div className="flex justify-between text-xs text-purple-800/80 font-medium">
                      <span>Packaging / Eco Token</span>
                      <span>₹{packagingFee}</span>
                    </div>
                    <div className="flex justify-between text-base font-black text-purple-950 pt-2 border-t border-purple-200">
                      <span>Total Payable</span>
                      <span className="text-purple-700">₹{total}</span>
                    </div>

                    <button
                      type="button"
                      onClick={handleCheckout}
                      disabled={!customerName || !customerPhone}
                      onMouseEnter={() => setCursorVariant('button')}
                      onMouseLeave={() => setCursorVariant('default')}
                      className={`w-full py-3.5 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition shadow-md ${
                        customerName && customerPhone
                          ? 'bg-gradient-to-r from-purple-700 via-purple-600 to-violet-600 text-white shadow-purple-600/25 cursor-pointer hover:opacity-95'
                          : 'bg-purple-100 text-purple-400 cursor-not-allowed'
                      }`}
                    >
                      <span>Generate QR Token (Pay at Counter)</span>
                      <ArrowRight className="w-4 h-4 stroke-[3]" />
                    </button>
                    {(!customerName || !customerPhone) && (
                      <p className="text-[11px] text-purple-600 text-center font-semibold">
                        Enter your name and phone number above to proceed.
                      </p>
                    )}
                  </div>
                )}
              </>
            ) : (
              /* Simulated Order Confirmation & QR Token Receipt in Purple & White */
              <div className="flex-1 p-6 flex flex-col items-center justify-center text-center">
                <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 border border-emerald-200 flex items-center justify-center mb-4 shadow-sm">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-black text-purple-950 mb-1">
                  Order Registered!
                </h3>
                <p className="text-purple-700/80 text-xs mb-6 max-w-xs font-medium">
                  Show this QR token at the canteen outlet counter to make payment and collect your food.
                </p>

                {/* QR Code Container */}
                <div className="p-5 rounded-3xl bg-white text-purple-950 border-2 border-purple-200 shadow-xl mb-4 flex flex-col items-center">
                  <QrCode className="w-36 h-36 text-purple-900" />
                  <span className="text-[11px] font-mono font-bold tracking-wider text-purple-700 mt-2">
                    TOKEN: REC-{Math.floor(100000 + Math.random() * 900000)}
                  </span>
                </div>

                <div className="text-xs text-purple-800 space-y-1 mb-8">
                  <p className="font-bold text-purple-950">Student: {customerName}</p>
                  <p>Phone: {customerPhone}</p>
                  <p className="text-purple-700 font-extrabold text-sm">Total: ₹{total}</p>
                </div>

                <button
                  onClick={handleReset}
                  className="px-6 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs transition cursor-pointer shadow-sm"
                >
                  Place Another Order
                </button>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
