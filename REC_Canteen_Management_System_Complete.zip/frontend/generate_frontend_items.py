import json
import re
import os

seed_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'REC_Canteen_Management_System', 'menu_seed.json'))
with open(seed_path, 'r', encoding='utf-8') as f:
    items = json.load(f)

print(f'Total seed items loaded: {len(items)}')

fallbacks = {
    'pizza': 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=600&h=400&q=80',
    'burger': 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&h=400&q=80',
    'sandwich': 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=600&h=400&q=80',
    'fries': 'https://images.unsplash.com/photo-1576107232684-1279f3908594?auto=format&fit=crop&w=600&h=400&q=80',
    'mojito': 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=600&h=400&q=80',
    'cooler': 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=600&h=400&q=80',
    'noodles': 'https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&w=600&h=400&q=80',
    'rice': 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&w=600&h=400&q=80',
    'biryani': 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&h=400&q=80',
    'juice': 'https://images.unsplash.com/photo-1546173159-315724a31696?auto=format&fit=crop&w=600&h=400&q=80',
    'coffee': 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=600&h=400&q=80',
    'tea': 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=600&h=400&q=80',
    'dessert': 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=600&h=400&q=80',
    'cake': 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=600&h=400&q=80',
    'stationery': 'https://images.unsplash.com/photo-1585776245991-cf89dd7fc73a?auto=format&fit=crop&w=600&h=400&q=80',
    'snack': 'https://images.unsplash.com/photo-1566478989037-eec170784d0b?auto=format&fit=crop&w=600&h=400&q=80',
    'chocolate': 'https://images.unsplash.com/photo-1549007994-cb92caebd54b?auto=format&fit=crop&w=600&h=400&q=80',
    'grocery': 'https://images.unsplash.com/photo-1583947215259-38e31be8751f?auto=format&fit=crop&w=600&h=400&q=80',
    'tiffin': 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=600&h=400&q=80',
    'parotta': 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&h=400&q=80',
    'default': 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=600&h=400&q=80'
}

def pick_fallback(name, cat, outlet):
    text = (name + ' ' + cat + ' ' + outlet).lower()
    for k, v in fallbacks.items():
        if k in text:
            return v
    return fallbacks['default']

def slugify(text):
    return re.sub(r'[^a-zA-Z0-9]+', '-', text).strip('-').lower()

food_items_code = []
for idx, it in enumerate(items):
    name = it['name']
    cat = it['category']
    outlet = it['outlet']
    price = it['price']
    slug = f'{slugify(outlet)}-{slugify(name)}-{idx}'
    
    rating = round(4.6 + (idx % 4) * 0.1, 1)
    
    is_stationery = any(w in cat.lower() for w in ['stationery', 'grocery', 'packaged', 'chocolate', 'biscuits', 'candies'])
    prep = 'Instant' if is_stationery else f'{3 + (idx % 7) * 2} mins'
    
    non_veg_terms = ['egg', 'chicken', 'fish', 'meat', 'omelette']
    is_veg = not any(term in name.lower() for term in non_veg_terms)
    
    clean_name = slugify(name)
    clean_cat = slugify(cat)
    ai_prompt = f'{clean_name}-{clean_cat}-delicious-food-photography-studio-lighting'
    
    desc = f'Freshly served from {outlet}. {cat} favorite crafted with high quality ingredients and authentic campus flavor.'
    fallback_img = pick_fallback(name, cat, outlet)
    
    food_items_code.append({
        'id': slug,
        'name': name,
        'category': outlet,
        'subCategory': cat,
        'price': price,
        'rating': rating,
        'outlet': outlet,
        'prepTime': prep,
        'isVeg': is_veg,
        'description': desc,
        'aiPrompt': ai_prompt,
        'imageUrl': fallback_img
    })

ts_lines = [
    "import { FoodItem } from '../types';",
    "",
    "export const CATEGORIES = [",
    "  'All',",
    "  \"Domino's\",",
    "  'Black Buck',",
    "  'REC Mart',",
    "  'Fresh Juice',",
    "  'Cafe (Cafe Seva)',",
    "  'Yippee',",
    "  'Wok On',",
    "  'Hotspot'",
    "] as const;",
    "",
    "export const FOOD_ITEMS: FoodItem[] = " + json.dumps(food_items_code, indent=2, ensure_ascii=False) + ";",
    "",
    "export function getPollinationsUrl(aiPrompt: string): string {",
    "  const cleanPrompt = aiPrompt.replace(/[^a-zA-Z0-9-]/g, '-').toLowerCase();",
    "  return `https://image.pollinations.ai/prompt/${cleanPrompt}?width=600&height=400&nologo=true`;",
    "}",
    ""
]

target_file = os.path.join(os.path.dirname(__file__), 'src', 'data', 'foodItems.ts')
with open(target_file, 'w', encoding='utf-8') as fp:
    fp.write('\n'.join(ts_lines))

print(f'Successfully wrote all {len(food_items_code)} items to frontend/src/data/foodItems.ts!')
